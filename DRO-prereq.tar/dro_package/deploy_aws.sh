#!/bin/sh
# currently written for ubuntu based systems

# Get the IP as input
if [ ! -z $1 ] && [ $1 = "dev" ]; then
   echo "******************         Running in dev mode           *****************"
fi
echo "Welcome to NetApp DRO Installation Wizard"
echo ""
echo "This Wizard will install DRO 2.0 on your system"
echo "NOTE: Ensure you are using an Ubuntu 20.04 OS"
echo ""
echo "Enter the host IP (In the format 10.10.10.10)"
read HOST_IP


##################      Check for dependencies on Host System       ##################
echo "Verifying if all dependencies are installed"
if ! command -v jq >/dev/null 2>&1; then
   apt-get update -y > /dev/null
   if ! [ $? -eq 0 ]; then
      echo "Failed to update apt packages"
      exit 2
   fi
   echo "[ ] Installing jq"
   apt-get install jq -y > /dev/null
   if ! [ $? -eq 0 ]; then
      echo "[X] Failed to install jq"
      exit 2
   else
      echo "[✔] Installed jq"
   fi
else
   echo "[✔] jq already installed"
fi

if [ -x "$(command -v docker)" ]; then
   echo "[✔] docker.io already installed"
else
   echo "[ ] Installing docker.io"
   apt-get install docker.io -y > /dev/null
   if ! [ $? -eq 0 ]; then
      echo "[X] Failed to install docker.io"
      exit 2
   else
      echo "[✔] Installed docker.io"
   fi
fi

if [ -x "$(command -v docker-compose)" ]; then
   echo "[✔] docker-compose already installed"
else
   echo "[ ] Installing docker-compose"
   apt-get install docker-compose -y > /dev/null
   if ! [ $? -eq 0 ]; then
      echo "Failed to install docker-compose"
      exit 2
   else
      echo "[✔] Installed docker-compose"
   fi
fi

if [ -x "$(command -v openssl)" ]; then
   echo "[✔] openssl already installed"
else
   echo "[ ] Installing openssl"
   apt-get install openssl -y > /dev/null
   if ! [ $? -eq 0 ]; then
      echo "[X] Failed to install openssl"
      exit 2
   else
      echo "[✔] Installed openssl"
   fi
fi

echo "All dependencies installed"

##################      Base Folder Setup and update Server IP       ##################

echo "Setting up base folder at /opt/netapp"
mkdir /opt/netapp
if ! [ $? -eq 0 ]; then
   echo "Failed to create directory"
   exit 2
else
   echo "Base Folder created successfully"
fi

cp dro_agent.tar /opt/netapp/
if ! [ $? -eq 0 ]; then
   echo "Failed to move dro_agent tar file to /opt/netapp"
   exit 2
fi

cp dro_app.tar /opt/netapp
if ! [ $? -eq 0 ]; then
   echo "Failed to move dro_app tar file to /opt/netapp"
   exit 2
fi

cp dro_nginx.tar /opt/netapp
if ! [ $? -eq 0 ]; then
   echo "Failed to move dro_nginx tar file to /opt/netapp"
   exit 2
fi

cd /opt/netapp
echo "Uncompressing dro_agent"
tar -xf dro_agent.tar
if ! [ $? -eq 0 ]; then
   echo "Failed to untar dro_agent.tar"
   exit 2
fi

echo "Uncompressing dro_app"
tar -xf dro_app.tar
if ! [ $? -eq 0 ]; then
   echo "Failed to untar dro_app.tar"
   exit 2
fi

echo "Uncompressing dro_nginx"
tar -xf dro_nginx.tar
if ! [ $? -eq 0 ]; then
   echo "Failed to untar dro_nginx.tar"
   exit 2
fi

rm /opt/netapp/dro_app.tar
rm /opt/netapp/dro_agent.tar
rm /opt/netapp/dro_nginx.tar

docker_repo="docker.repo.eng.netapp.com/user/tdhruv/"
if [ ! -z $1 ] && [ $1 = "dev" ]; then
  find /opt/netapp/dro_agent/.env -type f -exec sed -i -e "/^DOCKER_REPO=/s@=.*@=$docker_repo@" {} \;
  find /opt/netapp/dro_app/.env -type f -exec sed -i -e "/^DOCKER_REPO=/s@=.*@=$docker_repo@" {} \;
  find /opt/netapp/dro_nginx/.env -type f -exec sed -i -e "/^DOCKER_REPO=/s@=.*@=$docker_repo@" {} \;
fi

echo "Setting Server IP"
WHITELIST=`jq --compact-output --null-input '$ARGS.positional' --args -- "https://$HOST_IP"`

#recovery
cat /opt/netapp/dro_app/svc/dro-recovery/config/config.json | sudo jq -r --argjson whitelist "$WHITELIST" '.app.cors.whitelist |= $whitelist' | sudo jq '.' > config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to update IP address in dro-recovery config file"
   exit 2
fi

mv config.json /opt/netapp/dro_app/svc/dro-recovery/config/config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to update IP address in dro-recovery config file"
   exit 2
fi

#setup
sudo cat /opt/netapp/dro_app/svc/dro-setup/config/config.json | sudo jq -r --argjson whitelist "$WHITELIST" '.app.cors.whitelist |= $whitelist' | sudo jq '.' > config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to update IP address in dro-setup config file"
   exit 2
fi

mv config.json /opt/netapp/dro_app/svc/dro-setup/config/config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to update IP address in dro-setup config file"
   exit 2
fi

#tenant
sudo cat /opt/netapp/dro_app/svc/tenant/config/config.json | sudo jq -r --argjson whitelist "$WHITELIST" '.app.cors.whitelist |= $whitelist' | sudo jq '.' > config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to update IP address in tenant config file"
   exit 2
fi

mv config.json /opt/netapp/dro_app/svc/tenant/config/config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to update IP address in tenant config file"
   exit 2
fi

#workflow
sudo cat /opt/netapp/dro_app/svc/workflow/config/config.json | sudo jq -r --argjson whitelist "$WHITELIST" '.app.cors.whitelist |= $whitelist' | sudo jq '.' > config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to update IP address in workflow config file"
   exit 2
fi

mv config.json /opt/netapp/dro_app/svc/workflow/config/config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to update IP address in workflow config file"
   exit 2
fi

#ui
sed -i /opt/netapp/dro_app/svc/dro-ui/env/env-config.js -e "s/REACT_APP_RUNTIME_SERVER_IP.*/REACT_APP_RUNTIME_SERVER_IP: '${HOST_IP}',/" /opt/netapp/dro_app/svc/dro-ui/env/env-config.js
if ! [ $? -eq 0 ]; then
   echo "Failed to update IP address in UI config file"
   exit 2
fi

sed -i /opt/netapp/dro_app/svc/dro-ui/env/env-config.js -e "s/REACT_APP_RUNTIME_SOURCE_PLATFORM.*/REACT_APP_RUNTIME_SOURCE_PLATFORM: 'onprem, aws',/" /opt/netapp/dro_app/svc/dro-ui/env/env-config.js
if ! [ $? -eq 0 ]; then
   echo "Failed to update source site options in UI config file"
   exit 2
fi

sed -i /opt/netapp/dro_app/svc/dro-ui/env/env-config.js -e "s/REACT_APP_RUNTIME_TARGET_PLATFORM.*/REACT_APP_RUNTIME_TARGET_PLATFORM: 'aws',/" /opt/netapp/dro_app/svc/dro-ui/env/env-config.js
if ! [ $? -eq 0 ]; then
   echo "Failed to update destination site options in UI config file"
   exit 2
fi

cat > /opt/netapp/dro_nginx/conf.d/default.conf <<EOF
server {
    listen 443 ssl;
    #listen [::]:443 ssl;
    include snippets/self-signed.conf;
    #include snippets/ssl-params.conf;
    #listen       80;
    #listen  [::]:80;
    proxy_read_timeout 600;
    proxy_connect_timeout 600;
    proxy_send_timeout 600;
    server_name  localhost;

    client_max_body_size 50M;

    #access_log  /var/log/nginx/host.access.log  main;

    #location / {
    #    root   /usr/share/nginx/html;
    #    index  index.html index.htm;
    #}

    location / {
        proxy_pass http://dro-ui:3000;
    }

    location /api/tenant {
        proxy_pass http://tenant:3698;
    }

    location /api/setup {
        proxy_pass http://dro-setup:3700;
    }

    location /api/recovery {
        proxy_pass http://dro-recovery:3704;
    }

    location /api/discovery {
        proxy_pass http://dro-discovery:3701;
    }

    location /api/compliance {
        proxy_pass http://dro-compliance:3703;
    }

    location /api/execution {
        proxy_pass http://dro-execution:3702;
    }

    location /api/workflow {
        proxy_pass http://workflow:3699;
    }



    #error_page  404              /404.html;

    # redirect server error pages to the static page /50x.html
    #
    #error_page   500 502 503 504  /50x.html;
    #location = /50x.html {
    #    root   /usr/share/nginx/html;
    #}

    # proxy the PHP scripts to Apache listening on 127.0.0.1:80
    #
    #location ~ \.php$ {
    #    proxy_pass   http://127.0.0.1;
    #}

    # pass the PHP scripts to FastCGI server listening on 127.0.0.1:9000
    #
    #location ~ \.php$ {
    #    root           html;
    #    fastcgi_pass   127.0.0.1:9000;
    #    fastcgi_index  index.php;
    #    fastcgi_param  SCRIPT_FILENAME  /scripts$fastcgi_script_name;
    #    include        fastcgi_params;
    #}

    # deny access to .htaccess files, if Apache's document root
    # concurs with nginx's one
    #
    #location ~ /\.ht {
    #    deny  all;
    #}
}

server {
    listen 80;
    #listen [::]:80;

    server_name "${HOST_IP}";

    proxy_read_timeout 600;
    proxy_connect_timeout 600;
    proxy_send_timeout 600;

    client_max_body_size 50M;

    return 308 https://\$server_name\$request_uri;
}
EOF
if ! [ $? -eq 0 ]; then
   echo "Failed to update IP address in nginx config file"
   exit 2
fi

echo "Server IP set"


##################      Secret Setup      ##################

echo "Setting Database configuration"
DB_PWD=`openssl rand -base64 16 | tr -dc '[:alnum:]'`
if ! [ $? -eq 0 ]; then
   echo "Failed to create DB password"
   exit 2
fi

echo "DB_PWD: $DB_PWD"

NEW_UUID=`openssl rand -base64 20 | tr -dc '[:alnum:]'`
if ! [ $? -eq 0 ]; then
   echo "Failed to create DB key"
   exit 2
fi

# db password
algorithm='aes-256-ctr'
ivString=$(openssl rand -hex 16 | tr -dc '[:alnum:]')
if ! [ $? -eq 0 ]; then
   echo "Failed to create DB ivString"
   exit 2
fi

keyBytes=$(echo -n "$NEW_UUID" | openssl dgst -sha256 -hex | cut -d' ' -f2)
if ! [ $? -eq 0 ]; then
   echo "Failed to create DB keyBytes"
   exit 2
fi

encryptedPwd=$(echo -n "$DB_PWD" | openssl enc -${algorithm} -K "$keyBytes" -iv "$ivString" -a)
if ! [ $? -eq 0 ]; then
   echo "Failed to encrypt DB password"
   exit 2
fi

systemPwd=$(echo -n "_system" | openssl enc -${algorithm} -K "$keyBytes" -iv "$ivString" -a)
if ! [ $? -eq 0 ]; then
   echo "Failed to get system password"
   exit 2
fi

cat /opt/netapp/dro_app/svc/dro-setup/config/config.json | jq -r --arg systemPwd "$systemPwd" '.app.systemAccounts."f342aca3-bf30-40a8-b50b-446f3e90b94e".password |= $systemPwd' | jq '.' > config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to set secret key"
   exit 2
fi

mv config.json /opt/netapp/dro_app/svc/dro-setup/config/config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to set secret key"
   exit 2
fi

sed -i "s/dbpass/$DB_PWD/g" /opt/netapp/dro_app/db-setup.sh
if ! [ $? -eq 0 ]; then
   echo "Failed to update DB password in db_setup.sh"
   exit 2
fi

sed -i "s|user:dbpassword|dro_db_admin:$encryptedPwd|g" /opt/netapp/dro_app/svc/dro-recovery/config/config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to update DB password in dro-recovery config file"
   exit 2
fi

sed -i "s|user:dbpassword|dro_db_admin:$encryptedPwd|g" /opt/netapp/dro_app/svc/dro-setup/config/config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to update DB password in dro-setup config file"
   exit 2
fi

sed -i "s|user:dbpassword|dro_db_admin:$encryptedPwd|g" /opt/netapp/dro_app/svc/tenant/config/config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to update DB password in tenant config file"
   exit 2
fi

sed -i "s|user:dbpassword|dro_db_admin:$encryptedPwd|g" /opt/netapp/dro_app/svc/workflow/config/config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to update DB password in workflow config file"
   exit 2
fi

#recovery
cat /opt/netapp/dro_app/svc/dro-recovery/config/config.json | jq -r --arg secretKey "$NEW_UUID" '.app.secretKey |= $secretKey' | jq '.' > config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to set secret key in dro-recovery config file"
   exit 2
fi

mv config.json /opt/netapp/dro_app/svc/dro-recovery/config/config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to set secret key in dro-recovery config file"
   exit 2
fi

cat /opt/netapp/dro_app/svc/dro-recovery/config/config.json | jq -r --arg ivString "$ivString" '.app.ivString |= $ivString' | jq '.' > config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to set secret key in dro-recovery config file"
   exit 2
fi

mv config.json /opt/netapp/dro_app/svc/dro-recovery/config/config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to set secret key in dro-recovery config file"
   exit 2
fi

cat /opt/netapp/dro_app/svc/dro-recovery/config/config.json | jq -r --arg keyBytes "$keyBytes" '.app.keyBytes |= $keyBytes' | jq '.' > config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to set secret key"
   exit 2
fi

mv config.json /opt/netapp/dro_app/svc/dro-recovery/config/config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to set secret key in dro-recovery config file"
   exit 2
fi

#setup
cat /opt/netapp/dro_app/svc/dro-setup/config/config.json | jq -r --arg secretKey "$NEW_UUID" '.app.secretKey |= $secretKey' | jq '.' > config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to set secret key in dro-setup config file"
   exit 2
fi

mv config.json /opt/netapp/dro_app/svc/dro-setup/config/config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to set secret key in dro-setup config file"
   exit 2
fi

cat /opt/netapp/dro_app/svc/dro-setup/config/config.json | jq -r --arg ivString "$ivString" '.app.ivString |= $ivString' | jq '.' > config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to set secret key in dro-setup config file"
   exit 2
fi

mv config.json /opt/netapp/dro_app/svc/dro-setup/config/config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to set secret key in dro-setup config file"
   exit 2
fi

cat /opt/netapp/dro_app/svc/dro-setup/config/config.json | jq -r --arg keyBytes "$keyBytes" '.app.keyBytes |= $keyBytes' | jq '.' > config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to set secret key in dro-setup config file"
   exit 2
fi

mv config.json /opt/netapp/dro_app/svc/dro-setup/config/config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to set secret key in dro-setup config file"
   exit 2
fi

#tenant
cat /opt/netapp/dro_app/svc/tenant/config/config.json | jq -r --arg secretKey "$NEW_UUID" '.app.secretKey |= $secretKey' | jq '.' > config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to set secret key in tenant config file"
   exit 2
fi

mv config.json /opt/netapp/dro_app/svc/tenant/config/config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to set secret key in tenant config file"
   exit 2
fi

cat /opt/netapp/dro_app/svc/tenant/config/config.json | jq -r --arg ivString "$ivString" '.app.ivString |= $ivString' | jq '.' > config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to set secret key in tenant config file"
   exit 2
fi

mv config.json /opt/netapp/dro_app/svc/tenant/config/config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to set secret key in tenant config file"
   exit 2
fi

cat /opt/netapp/dro_app/svc/tenant/config/config.json | jq -r --arg keyBytes "$keyBytes" '.app.keyBytes |= $keyBytes' | jq '.' > config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to set secret key in tenant config file"
   exit 2
fi

mv config.json /opt/netapp/dro_app/svc/tenant/config/config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to set secret key in tenant config file"
   exit 2
fi

#workflow
cat /opt/netapp/dro_app/svc/workflow/config/config.json | jq -r --arg secretKey "$NEW_UUID" '.app.secretKey |= $secretKey' | jq '.' > config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to set secret key in workflow config file"
   exit 2
fi

mv config.json /opt/netapp/dro_app/svc/workflow/config/config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to set secret key in workflow config file"
   exit 2
fi

cat /opt/netapp/dro_app/svc/workflow/config/config.json | jq -r --arg ivString "$ivString" '.app.ivString |= $ivString' | jq '.' > config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to set secret key in workflow config file"
   exit 2
fi

mv config.json /opt/netapp/dro_app/svc/workflow/config/config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to set secret key in workflow config file"
   exit 2
fi

cat /opt/netapp/dro_app/svc/workflow/config/config.json | jq -r --arg keyBytes "$keyBytes" '.app.keyBytes |= $keyBytes' | jq '.' > config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to set secret key in workflow config file"
   exit 2
fi

mv config.json /opt/netapp/dro_app/svc/workflow/config/config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to set secret key in workflow config file"
   exit 2
fi

#discovery
cat /opt/netapp/dro_agent/dro-discovery/config/config.json | jq -r --arg secretKey "$NEW_UUID" '.app.secretKey |= $secretKey' | jq '.' > config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to set secret key in dro-discovery config file"
   exit 2
fi

mv config.json /opt/netapp/dro_agent/dro-discovery/config/config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to set secret key in dro-discovery config file"
   exit 2
fi

#execution
cat /opt/netapp/dro_agent/dro-execution/config/config.json | jq -r --arg secretKey "$NEW_UUID" '.app.secretKey |= $secretKey' | jq '.' > config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to set secret key in dro-execution config file"
   exit 2
fi

mv config.json /opt/netapp/dro_agent/dro-execution/config/config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to set secret key in dro-execution config file"
   exit 2
fi

echo "Completed Database configuration setup"

echo "Generating SSL Certificates"
openssl req -x509 -nodes -days 365 -newkey rsa:2048 -keyout /opt/netapp/dro_nginx/ssl/private/nginx-selfsigned.key -out /opt/netapp/dro_nginx/ssl/certs/nginx-selfsigned.crt -subj /C=/ST=/L=/O=/OU=/CN=$HOST_IP
if ! [ $? -eq 0 ]; then
   echo "Failed to generate SSL certificates"
   exit 2
fi
echo "SSL Certificates generated successfully"

##################      Run All Service Docker containers      ##################

echo "*****    Initializing DRO agent and app services    *****"

cd /opt/netapp/dro_agent/
docker-compose up -d
if ! [ $? -eq 0 ]; then
   echo "Failed to bring up Agent"
   exit 2
else
   echo "*****    Agent is up and running    *****"
fi

last_modified=$(stat -c "%Y" "/opt/netapp/dro_app/tenant_id.txt")

cd /opt/netapp/dro_app/
docker-compose -f db-setup-docker-compose.yml up -d
if ! [ $? -eq 0 ]; then
   echo "Failed to initialize database setup"
   exit 2
else
   echo ""
fi

while true; do
    echo -n "." 
    sleep 1
    current_modified=$(stat -c "%Y" "/opt/netapp/dro_app/tenant_id.txt")
    if [ "$current_modified" -gt "$last_modified" ]; then
        break
    fi
done
echo ""
echo "Database initialized successfully"

TENANT_ID=$(cat /opt/netapp/dro_app/tenant_id.txt | tr -d '\r\n' | sed 's/\//\\\//g')
echo "Tenant ID: $TENANT_ID"

sed -i 's/f342aca3-bf30-40a8-b50b-446f3e90b94e/'"$TENANT_ID"'/g' /opt/netapp/dro_app/svc/dro-setup/config/config.json
if ! [ $? -eq 0 ]; then
   echo "Failed to update Tenant ID in dro-setup config"
   exit 2
fi

docker-compose -f db-setup-docker-compose.yml down
rm -rf /opt/netapp/dro_app/db-setup-docker-compose.yml

docker-compose up -d
if ! [ $? -eq 0 ]; then
   echo "Failed to bring up App"
   exit 2
else
   echo "*****    App is up and running    *****"
fi

cd /opt/netapp/dro_nginx/
docker-compose up -d
if ! [ $? -eq 0 ]; then
   echo "Failed to bring up Nginx"
   exit 2
else
   echo "*****    Nginx is up and running    *****"
fi

echo "Initialization complete. DRO is now running. Access the service at https://${HOST_IP}"
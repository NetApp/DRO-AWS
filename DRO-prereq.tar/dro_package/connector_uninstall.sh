
echo "Welcome to NetApp DRO Uninstallation Wizard"
echo ""
echo "This Wizard will uninstall DRO 1.0 on your system"
echo "NOTE: You will loose all your existing data stored on DRO. Hence ensure to take a backup of /opt/netapp/dro_app/data folder"
echo ""
echo "Confirm if you want to proceed (Y/N)?"
read uninstall_bool

if [ "$uninstall_bool" = "Y" ] || [ "$uninstall_bool" = "y" ]; then    
    cd /opt/netapp/dro_nginx/
    docker-compose down
    cd /opt/netapp/dro_agent/
    docker-compose down
    if [ ! -z $1 ] && [ $1 = "dev" ]; then
        docker rmi -f docker.repo.eng.netapp.com/user/tdhruv/dro-execution > /dev/null
        docker rmi -f docker.repo.eng.netapp.com/user/tdhruv/dro-discovery > /dev/null
        docker rmi -f docker.repo.eng.netapp.com/user/tdhruv/dro-compliance > /dev/null
        docker rmi -f docker.repo.eng.netapp.com/user/tdhruv/dro_mongo > /dev/null
        docker rmi -f docker.repo.eng.netapp.com/user/tdhruv/dro_nginx > /dev/null
    else
        docker rmi -f netapp/dro:dro-execution > /dev/null
        docker rmi -f netapp/dro:dro-discovery > /dev/null
        docker rmi -f netapp/dro:dro-compliance > /dev/null
        docker rmi -f netapp/dro:dro_mongo > /dev/null
        docker rmi -f netapp/dro:dro_nginx > /dev/null
    fi
    sudo rm -rf /opt/netapp/
    cd ~
    echo "Uninstalled DRO successfully"
else
    echo "Exiting without uninstalling"
    exit
fi
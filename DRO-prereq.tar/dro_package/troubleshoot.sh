docker ps > docker-ps.txt
docker images > docker-images.txt
docker info > docker-info.txt
tar -czf dro-docker-command-output.tar docker-ps.txt docker-images.txt docker-info.txt 
tar -czf dro-troubleshoot.tar /opt/netapp/ /var/lib/docker/containers/ dro-docker-command-output.tar
rm docker-ps.txt
rm docker-images.txt
rm docker-info.txt
rm dro-docker-command-output.tar
echo -n "Troubleshoot file dro_troubleshoot.tar has been created and can be found at "
pwd

echo "Welcome to NetApp DRO Uninstallation Wizard"
echo ""
echo "This Wizard will uninstall DRO 3.0 on your system"
echo "NOTE: You will loose all your existing data stored on DRO. Hence ensure to take a backup of /opt/netapp/dro_app/data folder"
echo ""
echo "Confirm if you want to proceed (Y/N)?"
read uninstall_bool

if [ "$uninstall_bool" = "Y" ] || [ "$uninstall_bool" = "y" ]; then    
    cd /opt/netapp/dro_nginx/
    docker-compose down
    cd /opt/netapp/dro_app/
    docker-compose down
    cd /opt/netapp/dro_agent/
    docker-compose down
    if [ ! -z $1 ] && [ $1 = "dev" ]; then
        echo ""
        # docker rmi -f docker.repo.eng.netapp.com/user/psairam/dro-setup > /dev/null
        # docker rmi -f docker.repo.eng.netapp.com/user/psairam/dro-execution > /dev/null
        # docker rmi -f docker.repo.eng.netapp.com/user/psairam/dro-recovery > /dev/null
        # docker rmi -f docker.repo.eng.netapp.com/user/psairam/dro-ui > /dev/null
        # docker rmi -f docker.repo.eng.netapp.com/user/psairam/dro-workflow > /dev/null
        # docker rmi -f docker.repo.eng.netapp.com/user/psairam/dro-tenant > /dev/null
        # docker rmi -f docker.repo.eng.netapp.com/user/psairam/dro-discovery > /dev/null
        # docker rmi -f docker.repo.eng.netapp.com/user/psairam/dro-compliance > /dev/null
        # docker rmi -f docker.repo.eng.netapp.com/user/psairam/dro_mongo > /dev/null
        # docker rmi -f docker.repo.eng.netapp.com/user/psairam/dro_nginx > /dev/null
        # docker rmi -f docker.repo.eng.netapp.com/user/psairam/dro-monitoring > /dev/null
        # docker rmi -f docker.repo.eng.netapp.com/user/psairam/dro-scheduler > /dev/null
         # docker rmi -f docker.repo.eng.netapp.com/user/psairam/dro-data-mover > /dev/null
    else
        build_version="3.0"	
        docker rmi -f netapp/dro:dro-setup$build_version > /dev/null
        docker rmi -f netapp/dro:dro-execution$build_version > /dev/null
        docker rmi -f netapp/dro:dro-recovery$build_version > /dev/null
        docker rmi -f netapp/dro:dro-ui$build_version > /dev/null
        docker rmi -f netapp/dro:dro-workflow$build_version > /dev/null
        docker rmi -f netapp/dro:dro-tenant$build_version > /dev/null
        docker rmi -f netapp/dro:dro-discovery$build_version > /dev/null
        docker rmi -f netapp/dro:dro-compliance$build_version > /dev/null
        docker rmi -f netapp/dro:dro_mongo > /dev/null
        docker rmi -f netapp/dro:dro_nginx > /dev/null
        docker rmi -f netapp/dro:dro-monitoring$build_version > /dev/null
        docker rmi -f netapp/dro:dro-scheduler$build_version > /dev/null
        docker rmi -f netapp/dro:dro-data-mover$build_version > /dev/null
        
        # Deleting previous version images
        docker rmi -f netapp/dro:dro-setup > /dev/null
        docker rmi -f netapp/dro:dro-execution > /dev/null
        docker rmi -f netapp/dro:dro-recovery > /dev/null
        docker rmi -f netapp/dro:dro-ui > /dev/null
        docker rmi -f netapp/dro:dro-workflow > /dev/null
        docker rmi -f netapp/dro:dro-tenant > /dev/null
        docker rmi -f netapp/dro:dro-discovery > /dev/null
        docker rmi -f netapp/dro:dro-compliance > /dev/null
        docker rmi -f netapp/dro:dro-monitoring > /dev/null
        docker rmi -f netapp/dro:dro-scheduler > /dev/null
        docker rmi -f netapp/dro:dro-data-mover > /dev/null
    fi
    # Find the process ID (PID) of the running script
    script_path="/opt/netapp/dro_agent/monitoring/logs/pipeSetup.sh"
    pid1=$(ps aux | grep "sh pipeSetup.sh" | grep -v grep | awk '{print $2}')

    # If the script is running, stop it
    if [ -n "$pid1" ]; then
        kill "$pid1"
        echo "Stopped the running script with PID: $pid1"
    else
        echo "The script is not running."
    fi

     pid2=$(ps aux | grep "cat /opt/netapp/dro_agent/monitoring/logs/tmp-pipe" | grep -v grep | awk '{print $2}')

    # If the script is running, stop it
    if [ -n "$pid2" ]; then
        kill "$pid2"
        echo "Stopped the running script with PID: $pid2"
    else
        echo "The script is not running."
    fi

     pid3=$(ps aux | grep "/bin/bash /opt/netapp/dro_agent/monitoring/logs/pipeSetup.sh" | grep -v grep | awk '{print $2}')

    # If the script is running, stop it
    if [ -n "$pid3" ]; then
        kill "$pid3"
        echo "Stopped the running script with PID: $pid3"
    else
        echo "The script is not running."
    fi

    # Remove the script entry from the crontab
    if crontab -l | grep -q "$script_path"; then
        crontab -l | grep -v "$script_path" | crontab -
        echo "Removed the script entry from the crontab."
    else
        echo "The script entry is not present in the crontab."
    fi
    sudo rm -rf /opt/netapp/
    cd ~
    echo "Uninstalled DRO successfully"
else
    echo "Exiting without uninstalling"
    exit
fi